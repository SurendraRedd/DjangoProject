from django import forms
from django.forms import ModelForm

from .models import *


class DateInput(forms.DateInput):
    input_type = 'date'
    
class TaskForm(forms.ModelForm):
	toolName = forms.CharField(widget= forms.TextInput(attrs={'placeholder':'Tool Name...'}))
	title= forms.CharField(widget= forms.TextInput(attrs={'placeholder':'Issue Description...'}))
	toolVersion= forms.CharField(widget= forms.TextInput(attrs={'placeholder':'Tool Version...'}))
	#thumb = forms.ImageField()
	#due = forms.DateField(widget= DateInput(attrs={'type': 'date'}))
	class Meta:
		model = Task
		fields = '__all__'
