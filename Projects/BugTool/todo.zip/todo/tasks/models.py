from django.db import models

# Create your models here.
STATUS_VALUES = (
    ('Open','Open'),
    ('Closed', 'Closed'),
    ('Rejected','Rejected'),
    ('Deferred','Deferred'),
)

class Task(models.Model):
	title = models.TextField()
	toolName = models.CharField(max_length=20)
	toolVersion = models.CharField(max_length=10)
	thumb = models.ImageField(default='default.png',blank=True)
	status = models.CharField(max_length=10, choices=STATUS_VALUES, default='open')
	complete = models.BooleanField(default=False)
	created = models.DateTimeField(auto_now_add=True)
	#due = models.DateTimeField(auto_now_add=False, auto_now=False, blank=True, null=True)

	def __str__(self):
		return self.title
